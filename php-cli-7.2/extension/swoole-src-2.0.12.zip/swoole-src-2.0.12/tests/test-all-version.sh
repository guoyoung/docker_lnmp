to_php7.sh
cd ../
./make.sh
cd tests/
./start.sh
cd ../
./make.sh
cd tests/
to_php72.sh
cd ../
./make.sh
cd tests/
./start.sh

